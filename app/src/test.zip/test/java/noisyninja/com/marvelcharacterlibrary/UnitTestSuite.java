package noisyninja.com.marvelcharacterlibrary;

/**
 * Created by ir2pid on 17/03/16.
 */

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        EndpointMD5Tests.class,
        GsonMarshallUnmarshallTests.class
})
public class UnitTestSuite {
    @Before
    public void setUp() throws Exception {

        System.out.print("Running Test suite...");
    }


    @After
    public void tearDown() throws Exception {

        System.out.print("Completed Test suite...");
    }
}
